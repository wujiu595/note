# react-loadble



```shell
import Loadable from 'react-loadble'
```



```js
const LoadableComponent = Loadable({
    loader:()=>import("./"),
    loading(){
    	return <div> </div>
	}
});

export defaul <LoadableComponent/>
```



app.js

```js

```

