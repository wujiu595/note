### setState 异步 多个setState合并成一个setState

### ref

```
ref={(input)=>(this.input=input)}
```

setState

```js
this.setState(()=>{},()=>{})
```



动画 

```css
      display: block;
      float: left;
      font-size: 14px;
      transition: all .2s ease-in;
      transform: rotate(10deg);
      transform-origin: center center;
```

















