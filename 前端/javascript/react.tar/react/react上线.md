## React上线流程

### 打包构建

```shell
npm run build
```

