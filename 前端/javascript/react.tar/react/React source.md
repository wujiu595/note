reset-css:https://meyerweb.com/eric/tools/css/reset/

React英文文档:https://reactjs.org/

React常用包proptypes:https://reactjs.org/docs/typechecking-with-proptypes.html

Anted-Design:https://ant.design/docs/react/introduce-cn

semantic:https://react.semantic-ui.com/collections/breadcrumb/

redux-thunk:https://github.com/reduxjs/redux-thunk

redux-saga:https://github.com/redux-saga/redux-saga

react-transition-group:https://reactcommunity.org/react-transition-group/

